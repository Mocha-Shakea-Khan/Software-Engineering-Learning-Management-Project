#include "d_home.h"
#include "ui_d_home.h"

D_Home::D_Home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::D_Home)
{
    ui->setupUi(this);
}

D_Home::~D_Home()
{
    delete ui;
}
