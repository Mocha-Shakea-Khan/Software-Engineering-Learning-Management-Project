#include "richard_home.h"
#include "ui_richard_home.h"

Richard_Home::Richard_Home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Richard_Home)
{
    ui->setupUi(this);
}

Richard_Home::~Richard_Home()
{
    delete ui;
}

void Richard_Home::on_PLC_b_clicked()
{
    hide();
    PLC_Dio home;
    home.setModal(true);
    home.exec();
}

void Richard_Home::on_OS_b_clicked()
{
    hide();
    OS_home home;
    home.setModal(true);
    home.exec();
}

void Richard_Home::on_SP_B_clicked()
{
    hide();
    SP_home home;
    home.setModal(true);
    home.exec();
}

void Richard_Home::on_D_b_clicked()
{
    hide();
    D_Home home;
    home.setModal(true);
    home.exec();
}
