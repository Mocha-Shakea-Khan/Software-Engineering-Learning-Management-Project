#ifndef D_GUTS_H
#define D_GUTS_H

#include <QDialog>

namespace Ui {
class D_Guts;
}

class D_Guts : public QDialog
{
    Q_OBJECT

public:
    explicit D_Guts(QWidget *parent = nullptr);
    ~D_Guts();

private slots:
    void on_pushButton_3_clicked();

private:
    Ui::D_Guts *ui;
};

#endif // D_GUTS_H
