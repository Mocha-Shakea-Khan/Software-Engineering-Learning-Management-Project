#ifndef SS_HOME_H
#define SS_HOME_H

#include <QDialog>

namespace Ui {
class SS_home;
}

class SS_home : public QDialog
{
    Q_OBJECT

public:
    explicit SS_home(QWidget *parent = nullptr);
    ~SS_home();

private slots:
    void on_grade_b_clicked();

private:
    Ui::SS_home *ui;
};

#endif // SS_HOME_H
