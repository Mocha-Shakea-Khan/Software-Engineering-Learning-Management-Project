#ifndef RICHARD_GRADES_H
#define RICHARD_GRADES_H

#include <QDialog>

namespace Ui {
class Richard_grades;
}

class Richard_grades : public QDialog
{
    Q_OBJECT

public:
    explicit Richard_grades(QWidget *parent = nullptr);
    ~Richard_grades();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Richard_grades *ui;
};

#endif // RICHARD_GRADES_H
