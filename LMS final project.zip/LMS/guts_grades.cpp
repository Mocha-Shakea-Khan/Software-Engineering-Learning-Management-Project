#include "guts_grades.h"
#include "ui_guts_grades.h"

guts_grades::guts_grades(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::guts_grades)
{
    ui->setupUi(this);

    ui->listWidget->addItem("CS 4313 Database: A");
    ui->listWidget->addItem("CS 4315 Operating Systems: A");
    ui->listWidget->addItem("CS 4303 Pro Lang Concepts: B");
    ui->listWidget->addItem("CS 4294 Senior Seminar: A");
    ui->listWidget->addItem("GPA: 3.7");
}

guts_grades::~guts_grades()
{
    delete ui;
}
