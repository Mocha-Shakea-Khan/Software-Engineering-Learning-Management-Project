#include "os_esteban.h"
#include "ui_os_esteban.h"

OS_Esteban::OS_Esteban(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OS_Esteban)
{
    ui->setupUi(this);
}

OS_Esteban::~OS_Esteban()
{
    delete ui;
}
