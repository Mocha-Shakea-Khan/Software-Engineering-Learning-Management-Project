#include "os_sw.h"
#include "ui_os_sw.h"

OS_SW::OS_SW(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OS_SW)
{
    ui->setupUi(this);
}

OS_SW::~OS_SW()
{
    delete ui;
}
