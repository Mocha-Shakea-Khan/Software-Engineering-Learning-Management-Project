#include "sp_home.h"
#include "ui_sp_home.h"

SP_home::SP_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SP_home)
{
    ui->setupUi(this);
}

SP_home::~SP_home()
{
    delete ui;
}
