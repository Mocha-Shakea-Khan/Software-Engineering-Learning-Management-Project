﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (TextBox1.Text = "joey101") And (TextBox2.Text = "joe") Then
            Dim Login As Form2
            Login = New Form2()
            Login.Show()
            Login = Nothing
            Me.Close()
        Else
            lbl4.Text = "Error incorrect Username or password: "
        End If
    End Sub
End Class
