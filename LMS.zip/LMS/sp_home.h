#ifndef SP_HOME_H
#define SP_HOME_H

#include <QDialog>

namespace Ui {
class SP_home;
}

class SP_home : public QDialog
{
    Q_OBJECT

public:
    explicit SP_home(QWidget *parent = nullptr);
    ~SP_home();

private:
    Ui::SP_home *ui;
};

#endif // SP_HOME_H
