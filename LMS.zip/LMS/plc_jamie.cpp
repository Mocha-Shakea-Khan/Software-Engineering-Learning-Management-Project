#include "plc_jamie.h"
#include "ui_plc_jamie.h"

PLC_Jamie::PLC_Jamie(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PLC_Jamie)
{
    ui->setupUi(this);
}

PLC_Jamie::~PLC_Jamie()
{
    delete ui;
}
