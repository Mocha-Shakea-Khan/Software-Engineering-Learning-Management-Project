#include "guts_home.h"
#include "ui_guts_home.h"

Guts_home::Guts_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Guts_home)
{
    ui->setupUi(this);
}

Guts_home::~Guts_home()
{
    delete ui;
}

void Guts_home::on_pushButton_clicked()
{
    D_Guts home;
    home.setModal(true);
    home.exec();
}

void Guts_home::on_pushButton_5_clicked()
{
    guts_grades guts;
    guts.setModal(true);
    guts.exec();
}

void Guts_home::on_pushButton_2_clicked()
{
    OS_Dio home;
    home.setModal(true);
    home.exec();
}

void Guts_home::on_pushButton_3_clicked()
{
    PLC_Home home;
    home.setModal(true);
    home.exec();
}

void Guts_home::on_pushButton_4_clicked()
{
    SS_Guts home;
    home.setModal(true);
    home.exec();
}
