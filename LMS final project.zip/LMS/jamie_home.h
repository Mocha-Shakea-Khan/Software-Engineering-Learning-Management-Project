#ifndef JAMIE_HOME_H
#define JAMIE_HOME_H

#include <QDialog>
#include "plc_jamie.h"
#include "sp_jamie.h"
#include "jamie_grades.h"

namespace Ui {
class jamie_home;
}

class jamie_home : public QDialog
{
    Q_OBJECT

public:
    explicit jamie_home(QWidget *parent = nullptr);
    ~jamie_home();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::jamie_home *ui;
};

#endif // JAMIE_HOME_H
