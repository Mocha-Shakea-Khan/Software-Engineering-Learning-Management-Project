#include "plc_jamie.h"
#include "ui_plc_jamie.h"

PLC_Jamie::PLC_Jamie(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PLC_Jamie)
{
    ui->setupUi(this);
}

PLC_Jamie::~PLC_Jamie()
{
    delete ui;
}

void PLC_Jamie::on_pushButton_3_clicked()
{
    ui->listWidget->addItem("Exam 1 = 86");
    ui->listWidget->addItem("Exam 2 = 93");
    ui->listWidget->addItem("Final Exam = 91");
    ui->listWidget->addItem("Final Grade = 90");
}
