#include "os_dio.h"
#include "ui_os_dio.h"

OS_Dio::OS_Dio(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OS_Dio)
{
    ui->setupUi(this);
}

OS_Dio::~OS_Dio()
{
    delete ui;
}
