#include "plc_dio.h"
#include "ui_plc_dio.h"

PLC_Dio::PLC_Dio(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PLC_Dio)
{
    ui->setupUi(this);
}

PLC_Dio::~PLC_Dio()
{
    delete ui;
}
