#ifndef ESTEBAN_OS_H
#define ESTEBAN_OS_H

#include <QDialog>

namespace Ui {
class Esteban_OS;
}

class Esteban_OS : public QDialog
{
    Q_OBJECT

public:
    explicit Esteban_OS(QWidget *parent = nullptr);
    ~Esteban_OS();

private:
    Ui::Esteban_OS *ui;
};

#endif // ESTEBAN_OS_H
