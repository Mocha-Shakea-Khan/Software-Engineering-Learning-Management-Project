#include "joseph_os.h"
#include "ui_joseph_os.h"

joseph_os::joseph_os(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::joseph_os)
{
    ui->setupUi(this);
}

joseph_os::~joseph_os()
{
    delete ui;
}

void joseph_os::on_grade_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 87");
    ui->listWidget->addItem("Exam 2 = 65");
    ui->listWidget->addItem("Final Exam = 73");
    ui->listWidget->addItem("Final Grade = 75");
}
