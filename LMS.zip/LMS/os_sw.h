#ifndef OS_SW_H
#define OS_SW_H

#include <QDialog>

namespace Ui {
class OS_SW;
}

class OS_SW : public QDialog
{
    Q_OBJECT

public:
    explicit OS_SW(QWidget *parent = nullptr);
    ~OS_SW();

private:
    Ui::OS_SW *ui;
};

#endif // OS_SW_H
