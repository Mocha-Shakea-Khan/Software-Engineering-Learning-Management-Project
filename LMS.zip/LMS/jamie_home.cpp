#include "jamie_home.h"
#include "ui_jamie_home.h"

jamie_home::jamie_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::jamie_home)
{
    ui->setupUi(this);
}

jamie_home::~jamie_home()
{
    delete ui;
}

void jamie_home::on_pushButton_clicked()
{
    hide();
    PLC_Jamie home;
    home.setModal(true);
    home.exec();
}

void jamie_home::on_pushButton_2_clicked()
{
    hide();
    SP_Jamie home;
    home.setModal(true);
    home.exec();
}
