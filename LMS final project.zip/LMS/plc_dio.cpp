#include "plc_dio.h"
#include "ui_plc_dio.h"

PLC_Dio::PLC_Dio(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PLC_Dio)
{
    ui->setupUi(this);
}

PLC_Dio::~PLC_Dio()
{
    delete ui;
}

void PLC_Dio::on_grade_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 86");
    ui->listWidget->addItem("Exam 2 = 89");
    ui->listWidget->addItem("Final Exam = 91");
    ui->listWidget->addItem("Final Grade = 88");
}
