#ifndef PLC_HOME_H
#define PLC_HOME_H

#include <QDialog>

namespace Ui {
class PLC_Home;
}

class PLC_Home : public QDialog
{
    Q_OBJECT

public:
    explicit PLC_Home(QWidget *parent = nullptr);
    ~PLC_Home();

private slots:
    void on_grades_b_clicked();

private:
    Ui::PLC_Home *ui;
};

#endif // PLC_HOME_H
