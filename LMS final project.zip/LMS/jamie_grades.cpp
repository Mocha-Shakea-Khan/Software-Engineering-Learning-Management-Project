#include "jamie_grades.h"
#include "ui_jamie_grades.h"

jamie_grades::jamie_grades(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::jamie_grades)
{
    ui->setupUi(this);
    ui->listWidget->addItem("CS 4303 Pro Lang Concepts: A");
    ui->listWidget->addItem("CS 4395 Senior Project: A");
    ui->listWidget->addItem("GPA: 4.0");
}

jamie_grades::~jamie_grades()
{
    delete ui;
}
