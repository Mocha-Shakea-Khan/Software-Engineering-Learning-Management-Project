#ifndef ESTEBAN_GRADES_H
#define ESTEBAN_GRADES_H

#include <QDialog>

namespace Ui {
class esteban_grades;
}

class esteban_grades : public QDialog
{
    Q_OBJECT

public:
    explicit esteban_grades(QWidget *parent = nullptr);
    ~esteban_grades();

private:
    Ui::esteban_grades *ui;
};

#endif // ESTEBAN_GRADES_H
