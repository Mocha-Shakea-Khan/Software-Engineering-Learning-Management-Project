#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>
#include <QtSql/QSqlDatabase>
#include <QDebug>
#include <QFileInfo>
#include <QString>
#include <QSqlQuery>
#include "richard_home.h"
#include "jamie_home.h"
#include "joseph_home.h"
#include "esteban_home.h"

namespace Ui {
class Login;
}

class Login : public QMainWindow
{
    Q_OBJECT

public:
    QSqlDatabase db;

    void connClose()
    {
        db.close();
        db.removeDatabase(QSqlDatabase::defaultConnection);
    }
    bool connOpen()
    {
        db = QSqlDatabase::addDatabase("QSQLITE", "LMS");
        db.setDatabaseName("D:/Documents/Sqlite Database/LMS.db");

        if (db.open())
        {
            qDebug()<<("Connected...");
        return true;
        }
        else
        {
            qDebug()<<("Failed to connect");
            return false;
        }

    }

public:
    explicit Login(QWidget *parent = nullptr);
    ~Login();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Login *ui;    
};

#endif // LOGIN_H
