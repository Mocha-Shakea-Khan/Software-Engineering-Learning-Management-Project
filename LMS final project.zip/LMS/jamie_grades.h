#ifndef JAMIE_GRADES_H
#define JAMIE_GRADES_H

#include <QDialog>

namespace Ui {
class jamie_grades;
}

class jamie_grades : public QDialog
{
    Q_OBJECT

public:
    explicit jamie_grades(QWidget *parent = nullptr);
    ~jamie_grades();

private:
    Ui::jamie_grades *ui;
};

#endif // JAMIE_GRADES_H
