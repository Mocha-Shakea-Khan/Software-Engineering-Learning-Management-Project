#ifndef GUTS_GRADES_H
#define GUTS_GRADES_H

#include <QDialog>

namespace Ui {
class guts_grades;
}

class guts_grades : public QDialog
{
    Q_OBJECT

public:
    explicit guts_grades(QWidget *parent = nullptr);
    ~guts_grades();

private:
    Ui::guts_grades *ui;
};

#endif // GUTS_GRADES_H
