#include "plc_home.h"
#include "ui_plc_home.h"

PLC_Home::PLC_Home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PLC_Home)
{
    ui->setupUi(this);
    ui->listWidget->addItem("CS 4920");
}

PLC_Home::~PLC_Home()
{
    delete ui;
}
