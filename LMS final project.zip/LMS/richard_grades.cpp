#include "richard_grades.h"
#include "ui_richard_grades.h"

Richard_grades::Richard_grades(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Richard_grades)
{
    ui->setupUi(this);
    ui->listWidget->addItem("CS 4313 Database: A");
    ui->listWidget->addItem("CS 4315 Operating Systems: C");
    ui->listWidget->addItem("CS 4303 Pro Lang Concepts: B");
    ui->listWidget->addItem("CS 4395 Senior Project: B");
    ui->listWidget->addItem("GPA: 4");
}

Richard_grades::~Richard_grades()
{
    delete ui;
}

void Richard_grades::on_pushButton_clicked()
{

}
