#include "ss_guts.h"
#include "ui_ss_guts.h"

SS_Guts::SS_Guts(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SS_Guts)
{
    ui->setupUi(this);
}

SS_Guts::~SS_Guts()
{
    delete ui;
}

void SS_Guts::on_pushButton_3_clicked()
{
    ui->listWidget->addItem("Exam 1 = 98");
    ui->listWidget->addItem("Literature review = 90");
    ui->listWidget->addItem("Exam 2 = 93");
    ui->listWidget->addItem("Final Grade = 95");
}
