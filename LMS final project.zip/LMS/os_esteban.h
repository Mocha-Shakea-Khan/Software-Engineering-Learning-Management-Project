#ifndef OS_ESTEBAN_H
#define OS_ESTEBAN_H

#include <QDialog>

namespace Ui {
class OS_Esteban;
}

class OS_Esteban : public QDialog
{
    Q_OBJECT

public:
    explicit OS_Esteban(QWidget *parent = nullptr);
    ~OS_Esteban();

private slots:
    void on_grade_b_clicked();

private:
    Ui::OS_Esteban *ui;
};

#endif // OS_ESTEBAN_H
