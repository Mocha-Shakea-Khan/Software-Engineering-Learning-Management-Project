#include "esteban_home.h"
#include "ui_esteban_home.h"

Esteban_home::Esteban_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Esteban_home)
{
    ui->setupUi(this);
}

Esteban_home::~Esteban_home()
{
    delete ui;
}

void Esteban_home::on_OS_h_clicked()
{

   OS_Esteban os;
   os.setModal(true);
   os.exec();
}

void Esteban_home::on_SS_h_clicked()
{

    SS_home home;
    home.setModal(true);
    home.exec();
}

void Esteban_home::on_pushButton_clicked()
{
  esteban_grades grades;
  grades.setModal(true);
  grades.exec();
}
