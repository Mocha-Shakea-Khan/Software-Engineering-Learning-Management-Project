#ifndef JOSEPH_HOME_H
#define JOSEPH_HOME_H

#include <QDialog>
#include "joseph_os.h"

namespace Ui {
class joseph_home;
}

class joseph_home : public QDialog
{
    Q_OBJECT

public:
    explicit joseph_home(QWidget *parent = nullptr);
    ~joseph_home();

private slots:
    void on_os_b_clicked();

    void on_pushButton_clicked();

private:
    Ui::joseph_home *ui;
};

#endif // JOSEPH_HOME_H
