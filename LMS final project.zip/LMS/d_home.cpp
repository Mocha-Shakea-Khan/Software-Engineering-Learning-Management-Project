#include "d_home.h"
#include "ui_d_home.h"

D_Home::D_Home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::D_Home)
{
    ui->setupUi(this);
}

D_Home::~D_Home()
{
    delete ui;
}

void D_Home::on_grade_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 83");
    ui->listWidget->addItem("Exam 2 = 90");
    ui->listWidget->addItem("Team Project = 93");
    ui->listWidget->addItem("Final Exam = 91");
    ui->listWidget->addItem("Final Grade = 90");

}
