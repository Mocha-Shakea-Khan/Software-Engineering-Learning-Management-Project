#ifndef OS_HOME_H
#define OS_HOME_H

#include <QDialog>

namespace Ui {
class OS_home;
}

class OS_home : public QDialog
{
    Q_OBJECT

public:
    explicit OS_home(QWidget *parent = nullptr);
    ~OS_home();

private:
    Ui::OS_home *ui;
};

#endif // OS_HOME_H
