#include "sp_home.h"
#include "ui_sp_home.h"

SP_home::SP_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SP_home)
{
    ui->setupUi(this);
}

SP_home::~SP_home()
{
    delete ui;
}

void SP_home::on_grade_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 94");
    ui->listWidget->addItem("Exam 2 = 83");
    ui->listWidget->addItem("Project = 89");
    ui->listWidget->addItem("Final Exam = 85");
    ui->listWidget->addItem("Final Grade = 86");
}
