#include "os_dio.h"
#include "ui_os_dio.h"

OS_Dio::OS_Dio(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OS_Dio)
{
    ui->setupUi(this);
}

OS_Dio::~OS_Dio()
{
    delete ui;
}

void OS_Dio::on_grade_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 98");
    ui->listWidget->addItem("Exam 2 = 87");
    ui->listWidget->addItem("Final Exam = 93");
    ui->listWidget->addItem("Final Grade = 93");
}
