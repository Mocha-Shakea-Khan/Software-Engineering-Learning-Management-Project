#include "ss_home.h"
#include "ui_ss_home.h"

SS_home::SS_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SS_home)
{
    ui->setupUi(this);
}

SS_home::~SS_home()
{
    delete ui;
}
