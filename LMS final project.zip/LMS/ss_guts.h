#ifndef SS_GUTS_H
#define SS_GUTS_H

#include <QDialog>

namespace Ui {
class SS_Guts;
}

class SS_Guts : public QDialog
{
    Q_OBJECT

public:
    explicit SS_Guts(QWidget *parent = nullptr);
    ~SS_Guts();

private slots:
    void on_pushButton_3_clicked();

private:
    Ui::SS_Guts *ui;
};

#endif // SS_GUTS_H
