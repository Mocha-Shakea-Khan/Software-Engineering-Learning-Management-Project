#ifndef PLC_DIO_H
#define PLC_DIO_H

#include <QDialog>

namespace Ui {
class PLC_Dio;
}

class PLC_Dio : public QDialog
{
    Q_OBJECT

public:
    explicit PLC_Dio(QWidget *parent = nullptr);
    ~PLC_Dio();

private:
    Ui::PLC_Dio *ui;
};

#endif // PLC_DIO_H
