#ifndef OS_DIO_H
#define OS_DIO_H

#include <QDialog>

namespace Ui {
class OS_Dio;
}

class OS_Dio : public QDialog
{
    Q_OBJECT

public:
    explicit OS_Dio(QWidget *parent = nullptr);
    ~OS_Dio();

private slots:
    void on_grade_b_clicked();

private:
    Ui::OS_Dio *ui;
};

#endif // OS_DIO_H
