#ifndef GUTS_HOME_H
#define GUTS_HOME_H

#include <QDialog>
#include "plc_home.h"
#include "os_dio.h"
#include "ss_guts.h"
#include "d_guts.h"
#include "guts_grades.h"

namespace Ui {
class Guts_home;
}

class Guts_home : public QDialog
{
    Q_OBJECT

public:
    explicit Guts_home(QWidget *parent = nullptr);
    ~Guts_home();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::Guts_home *ui;
};

#endif // GUTS_HOME_H
