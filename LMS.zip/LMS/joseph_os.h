#ifndef JOSEPH_OS_H
#define JOSEPH_OS_H

#include <QDialog>

namespace Ui {
class joseph_os;
}

class joseph_os : public QDialog
{
    Q_OBJECT

public:
    explicit joseph_os(QWidget *parent = nullptr);
    ~joseph_os();

private slots:
    void on_grade_b_clicked();

private:
    Ui::joseph_os *ui;
};

#endif // JOSEPH_OS_H
