#include "sp_jamie.h"
#include "ui_sp_jamie.h"

SP_Jamie::SP_Jamie(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SP_Jamie)
{
    ui->setupUi(this);
}

SP_Jamie::~SP_Jamie()
{
    delete ui;
}
