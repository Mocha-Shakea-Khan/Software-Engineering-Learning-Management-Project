#ifndef JOSEPH_GRADES_H
#define JOSEPH_GRADES_H

#include <QDialog>

namespace Ui {
class joseph_grades;
}

class joseph_grades : public QDialog
{
    Q_OBJECT

public:
    explicit joseph_grades(QWidget *parent = nullptr);
    ~joseph_grades();

private:
    Ui::joseph_grades *ui;
};

#endif // JOSEPH_GRADES_H
