#ifndef RICHARD_HOME_H
#define RICHARD_HOME_H

#include <QDialog>
#include "plc_dio.h"
#include "os_home.h"
#include "sp_home.h"
#include "d_home.h"

namespace Ui {
class Richard_Home;
}

class Richard_Home : public QDialog
{
    Q_OBJECT

public:
    explicit Richard_Home(QWidget *parent = nullptr);
    ~Richard_Home();

private slots:
    void on_PLC_b_clicked();

    void on_OS_b_clicked();

    void on_SP_B_clicked();

    void on_D_b_clicked();

private:
    Ui::Richard_Home *ui;
};

#endif // RICHARD_HOME_H
