#ifndef D_HOME_H
#define D_HOME_H

#include <QDialog>

namespace Ui {
class D_Home;
}

class D_Home : public QDialog
{
    Q_OBJECT

public:
    explicit D_Home(QWidget *parent = nullptr);
    ~D_Home();

private:
    Ui::D_Home *ui;
};

#endif // D_HOME_H
