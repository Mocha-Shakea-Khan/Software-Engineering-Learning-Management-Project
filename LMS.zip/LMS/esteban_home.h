#ifndef ESTEBAN_HOME_H
#define ESTEBAN_HOME_H

#include <QDialog>
#include "ss_home.h"
#include "os_esteban.h"

namespace Ui {
class Esteban_home;
}

class Esteban_home : public QDialog
{
    Q_OBJECT

public:
    explicit Esteban_home(QWidget *parent = nullptr);
    ~Esteban_home();

private slots:
    void on_OS_h_clicked();

    void on_SS_h_clicked();

private:
    Ui::Esteban_home *ui;
};

#endif // ESTEBAN_HOME_H
