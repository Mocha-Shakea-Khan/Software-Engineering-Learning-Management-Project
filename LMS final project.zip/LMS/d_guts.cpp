#include "d_guts.h"
#include "ui_d_guts.h"

D_Guts::D_Guts(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::D_Guts)
{
    ui->setupUi(this);
}

D_Guts::~D_Guts()
{
    delete ui;
}

void D_Guts::on_pushButton_3_clicked()
{
    ui->listWidget->addItem("Exam 1 = 89");
    ui->listWidget->addItem("Exam 2 = 92");
    ui->listWidget->addItem("Team Project = 88");
    ui->listWidget->addItem("Final Exam = 91");
    ui->listWidget->addItem("Final Grade = 91");

}
