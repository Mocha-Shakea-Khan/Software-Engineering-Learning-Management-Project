#include "os_home.h"
#include "ui_os_home.h"

OS_home::OS_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OS_home)
{
    ui->setupUi(this);
}

OS_home::~OS_home()
{
    delete ui;
}
