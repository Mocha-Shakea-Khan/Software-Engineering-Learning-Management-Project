In order to compile the project save the sqlite database anywhere in your drive. 
The lms project needs a direct path to connect to the database. 
To open the qt file load the qt project file called LMS pro. 
Once loaded click the expand button to display the header, source, and form files. 
Headers is the file we need, ignore the rest. Expand headers and double click login.h. 
Within the namespace ui, there's a class Login; you should see public: QsqlDatabase db;
within the function bool connOpen() this code should be visible

db = QSqlDatabase::addDatabase("QSQLITE", "LMS");
db.setDatabaseName("D:/Documents/Sqlite Database/LMS.db");


D:/Documents/Sqlite Database/LMS.db   
is the path to the database in my drive
replace this with whatever your path is.
