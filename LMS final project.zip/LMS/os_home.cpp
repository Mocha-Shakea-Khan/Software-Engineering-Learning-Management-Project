#include "os_home.h"
#include "ui_os_home.h"

OS_home::OS_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OS_home)
{
    ui->setupUi(this);
}

OS_home::~OS_home()
{
    delete ui;
}

void OS_home::on_grade_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 77");
    ui->listWidget->addItem("Exam 2 = 83");
    ui->listWidget->addItem("Final Exam = 81");
    ui->listWidget->addItem("Final Grade = 79");
}
