#ifndef PLC_JAMIE_H
#define PLC_JAMIE_H

#include <QDialog>

namespace Ui {
class PLC_Jamie;
}

class PLC_Jamie : public QDialog
{
    Q_OBJECT

public:
    explicit PLC_Jamie(QWidget *parent = nullptr);
    ~PLC_Jamie();

private slots:
    void on_pushButton_3_clicked();

private:
    Ui::PLC_Jamie *ui;
};

#endif // PLC_JAMIE_H
