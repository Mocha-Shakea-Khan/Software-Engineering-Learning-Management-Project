#include "joseph_grades.h"
#include "ui_joseph_grades.h"

joseph_grades::joseph_grades(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::joseph_grades)
{
    ui->setupUi(this);

    ui->listWidget->addItem("CS 4315 Opertaing System: C");
    ui->listWidget->addItem("GPA: 2.0");
}

joseph_grades::~joseph_grades()
{
    delete ui;
}
