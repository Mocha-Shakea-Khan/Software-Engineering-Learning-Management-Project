#include "os_esteban.h"
#include "ui_os_esteban.h"

OS_Esteban::OS_Esteban(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OS_Esteban)
{
    ui->setupUi(this);
}

OS_Esteban::~OS_Esteban()
{
    delete ui;
}



void OS_Esteban::on_grade_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 63");
    ui->listWidget->addItem("Exam 2 = 44");
    ui->listWidget->addItem("Final Exam = 58");
    ui->listWidget->addItem("Final Grade = 55");
}
