#include "joseph_home.h"
#include "ui_joseph_home.h"

joseph_home::joseph_home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::joseph_home)
{
    ui->setupUi(this);
}

joseph_home::~joseph_home()
{
    delete ui;
}

void joseph_home::on_os_b_clicked()
{
    hide();
    joseph_os home;
    home.setModal(true);
    home.exec();
}

void joseph_home::on_pushButton_clicked()
{

    ui->listWidget->addItem()
}
