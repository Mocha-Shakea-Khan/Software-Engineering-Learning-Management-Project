#include "plc_home.h"
#include "ui_plc_home.h"

PLC_Home::PLC_Home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PLC_Home)
{
    ui->setupUi(this);
}

PLC_Home::~PLC_Home()
{
    delete ui;
}

void PLC_Home::on_grades_b_clicked()
{
    ui->listWidget->addItem("Exam 1 = 89");
    ui->listWidget->addItem("Exam 2 = 81");
    ui->listWidget->addItem("Final Exam = 83");
    ui->listWidget->addItem("Final Grade = 85");
}
