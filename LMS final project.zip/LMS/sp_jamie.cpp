#include "sp_jamie.h"
#include "ui_sp_jamie.h"

SP_Jamie::SP_Jamie(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SP_Jamie)
{
    ui->setupUi(this);
}

SP_Jamie::~SP_Jamie()
{
    delete ui;
}

void SP_Jamie::on_pushButton_3_clicked()
{
    ui->listWidget->addItem("Exam 1 = 94");
    ui->listWidget->addItem("Exam 2 = 91");
    ui->listWidget->addItem("Project = 89");
    ui->listWidget->addItem("Final Exam = 92");
    ui->listWidget->addItem("Final Grade = 93");
}
