#include "esteban_os.h"
#include "ui_esteban_os.h"

Esteban_OS::Esteban_OS(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Esteban_OS)
{
    ui->setupUi(this);
}

Esteban_OS::~Esteban_OS()
{
    delete ui;
}
