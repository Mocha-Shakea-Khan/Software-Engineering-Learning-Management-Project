#include "esteban_grades.h"
#include "ui_esteban_grades.h"

esteban_grades::esteban_grades(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::esteban_grades)
{
    ui->setupUi(this);
    ui->listWidget->addItem("CS 4315 Operating Systems: F");
    ui->listWidget->addItem("CS 4395 Senior Seminar: C");
    ui->listWidget->addItem("GPA: 0.8");
}

esteban_grades::~esteban_grades()
{
    delete ui;
}
