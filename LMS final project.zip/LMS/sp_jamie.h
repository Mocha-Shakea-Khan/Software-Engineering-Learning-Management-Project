#ifndef SP_JAMIE_H
#define SP_JAMIE_H

#include <QDialog>

namespace Ui {
class SP_Jamie;
}

class SP_Jamie : public QDialog
{
    Q_OBJECT

public:
    explicit SP_Jamie(QWidget *parent = nullptr);
    ~SP_Jamie();

private slots:
    void on_pushButton_3_clicked();

private:
    Ui::SP_Jamie *ui;
};

#endif // SP_JAMIE_H
