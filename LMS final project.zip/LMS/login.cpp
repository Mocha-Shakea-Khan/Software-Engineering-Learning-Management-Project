#include "login.h"
#include "ui_login.h"

Login::Login(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);

    if (connOpen())
        ui->db_label->setText("Connected...");
    else {
        ui->db_label->setText("Failed to connect");
    }
}

Login::~Login()
{
    delete ui;
}



void Login::on_pushButton_clicked()
{
    QString username, password;
    username = ui->lineEdit_username->text();
    password = ui->lineEdit_password->text();

    if (!connOpen())
    {
        qDebug()<<"Failed to open database";
        return ;
    }

    connOpen();
    QSqlQuery *qry = new QSqlQuery(db);
     qry->prepare("select * from Students where ID='"+ username + "' and password='"+ password +"'");
    if (qry->exec())
    {
        if (username == "Richytive13" && password == "EbKJGS4q")
                {
                    connClose();
                    hide();
                    Richard_Home richard;
                    richard.setModal(true);
                    richard.exec();
                }
        else if (username == "Mejiaavel6" && password == "08ULgZFt")
        {
            connClose();
            hide();
            Esteban_home esteban;
            esteban.setModal(true);
            esteban.exec();
        }
        else if (username == "GriffithPieta17" && password == "iiTo9tsh")
        {
            connClose();
            hide();
            Guts_home home;
            home.setModal(true);
            home.exec();
        }
        else if (username == "LanisterDoh5" && password == "eJ7j99ED")
        {
            connClose();
            hide();
            jamie_home jamie;
            jamie.setModal(true);
            jamie.exec();
        }
        else if (username == "ShoboikiBel8" && password == "onnnL8R8")
        {
            connClose();
            hide();
            joseph_home jo;
            jo.setModal(true);
            jo.exec();
        }
        else
            {
                    ui->db_label->setText("username or password is incorrect");
            }
    }
}
